     function startGame() {
         window.location.href = "game.html";
     }

     function openTutorial() {
         window.location.href = "tutorial.html";
     }